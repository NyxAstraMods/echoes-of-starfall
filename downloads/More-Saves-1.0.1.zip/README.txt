More Saves 1.0.1 - Starsand Island
==================================
15 save slots instead of 3, shown as 5 pages of 3 cards.
Change page with the arrows next to the cards, or with a controller by moving
left/right off the edge of the row. The page number is shown under the cards.
Empty slots show as "New Game" cards.

NEW IN 1.0.1
- Turning pages is instant: the characters on the cards no longer load again
  every time you change page. They load once, when the save screen opens.

NEEDS
- BepInEx 6 (IL2CPP) installed in Starsand Island.

INSTALL
1. Close the game.
2. Back up your saves first. Copy this folder somewhere safe:
   C:\Users\<you>\AppData\LocalLow\SeedLab\StarsandIsland\steam\<number>\Save
3. Copy the "BepInEx" folder from this zip into the game folder
   (the folder with StarsandIsland.exe). Say yes if Windows asks to merge folders.
   This puts:
   - MoreSaves.dll in BepInEx\plugins\MoreSaves\
   - the settings file in BepInEx\config\
4. Start the game.

CHANGE THE NUMBER OF SLOTS
1. Close the game.
2. Open BepInEx\config\com.phoenix.starsandmoresaveslots.cfg in Notepad.
3. Change "SlotCount = 15" to any number from 3 to 51.
   Use a multiple of 3 (6, 9, 12, 15, 18 ... 51) so every page has 3 cards.
4. Save the file and start the game.

- Don't set it lower than the number of saves you already have. Those saves are
  not deleted, but they won't show until you raise the number again.
- Empty slots cost nothing. Lots of REAL saves (30+) can make the save screen
  open a bit slower, because the game loads every save's picture.
- If the save screen looks broken, set "Pages = false" in the same file.

UNINSTALL
- Delete BepInEx\plugins\MoreSaves.
- The game shows slots 1 to 3 again. Your other saves are NOT deleted
  (folders Role_4, Role_5 ... stay in the Save folder). Reinstall and they come back.

GOOD TO KNOW
- Steam Cloud may not back up slots 4 and up. Keep your own backups of the Save folder.
- The mod never lowers the game's own slot number.
